require("dotenv").config();
const createError = require("http-errors");
const express = require("express");
const path = require("path");
const cookieParser = require("cookie-parser");
const morganLogger = require("morgan");              // ✅ Renamed to avoid conflict
const expressLayouts = require("express-ejs-layouts");
const session = require("express-session");
const csrf = require("csurf");
const flash = require("connect-flash");
const MongoStore = require("connect-mongo");
const nocache = require("nocache");
const methodOverride = require("method-override");
const passport = require("./src/config/passport-config");
const helmet = require("helmet");

// Winston logger
const logger = require('./logger');

// ✅ Test logs on server start
logger.info('🟢 Server bootstrapping initiated');
logger.warn('⚠️ Testing warning: Check session or CSRF configurations');
logger.error('❌ This is a test error log (ignore if seen during setup)');

const app = express();
const connectDB = require("./src/config/db");

// Routes
const authRouter = require("./src/routes/authRoute");
const userRouter = require("./src/routes/userRoute");
const adminRouter = require("./src/routes/adminRoute");

// ✅ DB Connection
connectDB().then(() => logger.info("✅ Connected to MongoDB"))
           .catch((err) => logger.error(`❌ MongoDB connection error: ${err.message}`));

// Disable "X-Powered-By" header
app.disable("x-powered-by");

// View engine setup
app.use(expressLayouts);
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");
app.set("layout", "./layouts/userLayout");

// Middleware
app.use(morganLogger("dev"));                        // ✅ Use morganLogger
app.use(methodOverride("_method"));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());

// Static files and no-cache
app.use(express.static(path.join(__dirname, "public")));
app.use(nocache());

// Helmet security headers
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));

// Custom security headers
app.use((req, res, next) => {
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "geolocation=(), microphone=()");
  next();
});

// Session setup
app.use(session({
  secret: process.env.SECRET || "fallback-secret",
  resave: false,
  saveUninitialized: false,
  store: MongoStore.create({
    mongoUrl: process.env.MONGODB_URI,
    ttl: 24 * 60 * 60,
  }),
  cookie: {
    httpOnly: true,
    secure: false,
    maxAge: 24 * 60 * 60 * 1000,
    sameSite: "Lax",
  },
}));

// Passport and flash
app.use(flash());
app.use(passport.initialize());
app.use(passport.session());

// CSRF protection
app.use(csrf());

// Set csrf, flash, and user to locals
app.use((req, res, next) => {
  res.locals.csrfToken = req.csrfToken();
  res.locals.success = req.flash("success");
  res.locals.error = req.flash("error");
  res.locals.user = req.user || null;
  logger.info(`🔄 Request: ${req.method} ${req.url} | User: ${req.user ? req.user.email : 'Guest'}`);
  next();
});

// Routes
app.use("/", authRouter);
app.use("/", userRouter);
app.use("/admin", adminRouter);

// 404 handler
app.use((req, res, next) => {
  logger.warn(`🔍 404 Not Found: ${req.method} ${req.url}`);
  next(createError(404));
});

// CSRF error handler
app.use((err, req, res, next) => {
  if (err.code === "EBADCSRFTOKEN") {
    logger.error("🚫 CSRF token validation failed");
    req.flash("error", "Form has expired or was tampered with.");
    return res.redirect("back");
  }
  next(err);
});

// Error handler
app.use((err, req, res, next) => {
  logger.error(`🔥 Server error: ${err.status || 500} - ${err.message}`);
  res.locals.message = err.message;
  res.locals.error = req.app.get("env") === "development" ? err : {};
  res.status(err.status || 500);
  res.render("error");
});

module.exports = app;

