const bcrypt = require("bcrypt");
const adminLayout = "./layouts/adminLayout.ejs";
const User = require("../model/userSchema");
const passport = require("../config/passport-config");

module.exports = {
  // ======= User GET Routes =======
  getUserLogin: (req, res) => {
    if (req.user) return res.redirect("/");

    const locals = { title: "User Login" };
    res.render("user/login", {
      locals,
      success: req.flash("success"),
      error: req.flash("error"),
    });
  },

  getUserRegister: (req, res) => {
    const locals = { title: "User Register" };
    res.render("user/register", {
      locals,
      success: req.flash("success"),
      error: req.flash("error"),
    });
  },

  // ======= User POST Routes =======
  userRegister: async (req, res) => {
    const { firstName, lastName, email, pwd, pwdConf } = req.body;

    const isExist = await User.findOne({ email });
    if (isExist) {
      req.flash("error", "User already exists, Please login");
      console.log("User already exists, Please login");
      return res.redirect("/login");
    }

    if (pwd.length < 8 || pwdConf.length < 8) {
      req.flash("error", "Password must be at least 8 characters");
      console.log("Password is too short");
      return res.redirect("/register");
    }

    if (pwd !== pwdConf) {
      req.flash("error", "Passwords do not match");
      console.log("Password does not match");
      return res.redirect("/register");
    }

    const hashpwd = await bcrypt.hash(pwd, 12);
    const user = await User.create({ firstName, lastName, email, password: hashpwd });

    if (user) {
      req.flash("success", "User successfully created!!");
      return res.redirect("/login");
    } else {
      req.flash("error", "User not created");
      return res.redirect("/register");
    }
  },

  userLogin: (req, res, next) => {
    const { email, password } = req.body;

    if (!email || !password) {
      req.flash("error", "Email and password are required");
      return res.redirect("/login");
    }

    passport.authenticate("user-local", (err, user, info) => {
      if (err) return next(err);
      if (!user) {
        req.flash("error", info.message);
        return res.redirect("/login");
      }

      req.logIn(user, (err) => {
        if (err) return next(err);
        return res.redirect("/");
      });
    })(req, res, next);
  },

  // ======= Admin GET Routes =======
  getAdminLogin: (req, res) => {
    const locals = { title: "Admin Login" };
    res.render("admin/login", {
      locals,
      success: req.flash("success"),
      error: req.flash("error"),
      layout: adminLayout,
    });
  },

  getAdminRegister: (req, res) => {
    const locals = { title: "Admin Register" };
    res.render("admin/register", {
      locals,
      success: req.flash("success"),
      error: req.flash("error"),
      layout: adminLayout,
    });
  },

  // ======= Admin POST Routes =======
  adminRegister: async (req, res) => {
    const { firstName, lastName, email, pwd, pwdConf } = req.body;

    const isExist = await User.findOne({ email });
    if (isExist) {
      req.flash("error", "User already exists, Please login");
      console.log("User already exists, Please login");
      return res.redirect("/login");
    }

    if (pwd.length < 6 || pwdConf.length < 6) {
      req.flash("error", "Password must be at least 6 characters");
      return res.redirect("/admin/register");
    }

    if (pwd !== pwdConf) {
      req.flash("error", "Passwords do not match");
      console.log("Password does not match");
      return res.redirect("/admin/register");
    }

    const hashpwd = await bcrypt.hash(pwd, 12);
    const user = await User.create({
      firstName,
      lastName,
      email,
      password: hashpwd,
      isAdmin: true,
    });

    if (user) {
      req.flash("success", "User successfully created!!");
      return res.redirect("/admin/login");
    } else {
      req.flash("error", "User not created");
      return res.redirect("/admin/register");
    }
  },

  adminLogin: (req, res, next) => {
    const { email, password } = req.body;

    if (!email || !password) {
      req.flash("error", "Email and password are required");
      return res.redirect("/admin/login");
    }

    passport.authenticate("admin-local", (err, user, info) => {
      if (err) return next(err);
      if (!user) {
        req.flash("error", "Invalid Credentials!!!");
        return res.redirect("/admin/login");
      }

      req.logIn(user, (err) => {
        if (err) return next(err);
        req.flash("success", "Admin Logged In");
        return res.redirect("/admin");
      });
    })(req, res, next);
  },

  // ======= Logout Routes =======
  logout: (req, res) => {
    req.logOut((err) => {
      if (err) console.log(err);
      req.flash("success", "Logged Out!!");
      res.clearCookie("connect.sid");
      res.redirect("/login");
    });
  },

  adminLogout: (req, res) => {
    req.logOut((err) => {
      if (err) console.log(err);
      req.flash("success", "Logged Out!!");
      res.clearCookie("connect.sid");
      res.redirect("/admin/login");
    });
  },
};

