const express = require('express')
const router = express.Router()

function isAdmin(req, res, next) {
  if (req.user && req.user.role === 'admin') {
    return next();
  }
  req.flash('error', 'Access denied');
  res.redirect('/login');
}


// Admin Controller
const adminController = require('../controller/adminController')
const { isAdminLoggedIn} = require('../middleware/authMiddleware')

router.get('/', isAdminLoggedIn, isAdmin, adminController.getDashboard)

router
  .get('/add-user', isAdminLoggedIn, isAdmin, adminController.getAddUser)
  .post('/add-user', isAdminLoggedIn, isAdmin, adminController.addUser)

router.get('/view/:id', isAdminLoggedIn, isAdmin, adminController.viewUser)

router
  .get('/edit/:id', isAdminLoggedIn, isAdmin, adminController.getEditUser)
  .post('/edit/:id', isAdminLoggedIn, isAdmin, adminController.editUser)
  .delete('/edit/:id', isAdminLoggedIn, isAdmin, adminController.deleteUser)

router.post('/search', isAdminLoggedIn, isAdmin, adminController.searchUsers)


module.exports = router
